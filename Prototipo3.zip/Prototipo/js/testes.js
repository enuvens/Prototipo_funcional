function ValidaLogin(frm) {
    if (frm.email.value == "" || frm.email.value == null) {
        frm.email.focus();
        document.getElementById('email').style = 'border: 1px solid #FF0000';
        return false;
    }
    if (frm.senha.value == "" || frm.senha.value == null) {
        frm.senha.focus();
        document.getElementById('senha').style = 'border: 1px solid #FF0000';
        return false;
    }

    if (frm.email.value == "user@area.com" && frm.senha.value == "123456") {
        return true;
    } else {
        window.alert('Login ou senha inválidos!');
        return false;
    }
}

$(document).ready(function() {

    console.log('    ______     __    __     ______     ______     ______      ______   ______     ______     ______   ______     ______     __  __    ');
    console.log('    /\  ___\   /\ "-./  \   /\  __ \   /\  == \   /\__  _\    /\  ___\ /\  __ \   /\  ___\   /\__  _\ /\  __ \   /\  == \   /\ \_\ \   ');
    console.log('    \ \___  \  \ \ \-./\ \  \ \  __ \  \ \  __<   \/_/\ \/    \ \  __\ \ \  __ \  \ \ \____  \/_/\ \/ \ \ \/\ \  \ \  __<   \ \____ \  ');
    console.log('     \/\_____\  \ \_\ \ \_\  \ \_\ \_\  \ \_\ \_\    \ \_\     \ \_\    \ \_\ \_\  \ \_____\    \ \_\  \ \_____\  \ \_\ \_\  \/\_____\ ');
    console.log('      \/_____/   \/_/  \/_/   \/_/\/_/   \/_/ /_/     \/_/      \/_/     \/_/\/_/   \/_____/     \/_/   \/_____/   \/_/ /_/   \/_____/ ');

    console.log('');
    console.log('');

    console.log('Desenvolvido por Danielle, Eduardo, Leticia, Marcus e Mayara');

});

function menu() {

    document.write('  <ul class="nav menu">');
    document.write('    <li class="active"><a href="index2.html"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> Painel de Controle</a></li>');
    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-clientes"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Clientes');
    document.write('      </a>');
    document.write('      <ul class="children" id="sub-item-clientes">');
    document.write('        <li>');
    document.write('          <a class="" href="clientes_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Listar Clientes');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="clientes_novo.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Cliente');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-venda"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Vendas');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-venda">');
    document.write('        <li>');
    document.write('          <a class="" href="vendas_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Listar Vendas');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="vendas_novo.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Venda');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-fornecedores"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Fornecedores');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-fornecedores">');
    document.write('        <li>');
    document.write('          <a class="" href="fornecedores_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Listar Fornecedores');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="fornecedores_novo.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Fornecedor');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-produto"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Produtos');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-produto">');
    document.write('        <li>');
    document.write('          <a class="" href="produtos_cadastrar.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Lista de Produtos');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="produtos_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Orderm de Produção');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-materia"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Matéria Prima');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-materia">');
    document.write('        <li>');
    document.write('          <a class="" href="matprima_compra.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Ordem de Compra');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="matprima_nova.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="matprima_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Em Estoque');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li><a href="estoque.html"><svg class="glyph stroked calendar"><use xlink:href="#stroked-calendar"></use></svg> Estoque</a></li>');
    document.write('    <li><a href="relatorios.html"><svg class="glyph stroked line-graph"><use xlink:href="#stroked-line-graph"></use></svg> Relatórios</a></li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-usuarios"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Usuários');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-usuarios">');
    document.write('        <li>');
    document.write('          <a class="" href="usuarios_novo.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Usuários');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="usuarios_regras.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Regras');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');
    document.write('  </ul>');

}