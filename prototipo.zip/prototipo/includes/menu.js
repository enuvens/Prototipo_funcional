var menu = '';
var p1 = "";
var p2 = "";
var p3 = "";
var p4 = "";
var p5 = "";
var p6 = "";
var p7 = "";
var p8 = "";

if (pagina == "painel"){        p1 = "active"; } else { p1 = "parent" }
if (pagina == "cliente"){       p2 = "active"; } else { p2 = "parent" }
if (pagina == "venda"){         p3 = "active"; } else { p3 = "parent" }
if (pagina == "fornecedor"){    p4 = "active"; } else { p4 = "parent" }
if (pagina == "materia_prima"){ p5 = "active"; } else { p5 = "parent" }
if (pagina == "estoque"){       p6 = "active"; } else { p6 = "parent" }
if (pagina == "relatorio"){     p7 = "active"; } else { p7 = "parent" }
if (pagina == "usuarios"){      p8 = "active"; } else { p8 = "parent" }

menu += '<li class="'+ p1 +'"><a href="index.html"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> Painel de Controle</a></li>\n';

menu += '<li class="'+ p2 +'">\n';
menu += '<a href="#">\n';
menu += '<span data-toggle="collapse" href="#sub-item-clientes"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Clientes\n';
menu += '  </a>\n';
menu += '  <ul class="children collapse" id="sub-item-clientes">\n';
menu += '    <li>\n';
menu += '      <a class="" href="clientes_lista.html">\n';
menu += '        <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Listar Clientes\n';
menu += '      </a>\n';
menu += '    </li>\n';
menu += '    <li>\n';
menu += '      <a class="" href="clientes_novo.html">\n';
menu += '        <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Cliente\n';
menu += '      </a>\n';
menu += '    </li>\n';
menu += '</li>\n';
menu += '</ul>\n';

menu += '<li class="'+ p3 +'">\n';
menu += '  <a href="#">\n';
menu += '    <span data-toggle="collapse" href="#sub-item-venda"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Vendas\n';
menu += '  </a>\n';
menu += '  <ul class="children collapse" id="sub-item-venda">\n';
menu += '    <li>\n';
menu += '      <a class="" href="vendas_lista.html">\n';
menu += '        <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Listar Vendas\n';
menu += '      </a>\n';
menu += '    </li>\n';
menu += '    <li>\n';
menu += '      <a class="" href="vendas_nova.html">\n';
menu += '        <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Venda\n';
menu += '      </a>\n';
menu += '    </li>\n';
menu += '  </ul>\n';
menu += '</li>\n';

menu += '<li class="'+ p4 +'">\n';
menu += '  <a href="#">\n';
menu += '    <span data-toggle="collapse" href="#sub-item-fornecedores"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Fornecedores\n';
menu += '  </a>\n';
menu += '  <ul class="children collapse" id="sub-item-fornecedores">\n';
menu += '    <li>\n';
menu += '      <a class="" href="fornecedores_lista.html">\n';
menu += '        <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Listar Fornecedores\n';
menu += '      </a>\n';
menu += '    </li>\n';
menu += '    <li>\n';
menu += '      <a class="" href="fornecedores_novo.html">\n';
menu += '        <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Fornecedor\n';
menu += '      </a>\n';
menu += '    </li>\n';
menu += '  </ul>\n';
menu += '</li>\n';

menu += '<li class="'+ p5 +'">\n';
menu += '  <a href="#">\n';
menu += '    <span data-toggle="collapse" href="#sub-item-materia"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Matéria Prima\n';
menu += '  </a>\n';
menu += '  <ul class="children collapse" id="sub-item-materia">\n';
menu += '    <li>\n';
menu += '      <a class="" href="materia_ordemcompra.html">\n';
menu += '        <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Ordem de Compra\n';
menu += '      </a>\n';
menu += '    </li>\n';
menu += '    <li>\n';
menu += '      <a class="" href="materia_lista.html">\n';
menu += '        <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Lista em estoque\n';
menu += '      </a>\n';
menu += '    </li>\n';
menu += '  </ul>\n';
menu += '</li>\n';

menu += '<li class="'+ p6 +'"><a href="estoque.html"><svg class="glyph stroked calendar"><use xlink:href="#stroked-calendar"></use></svg> Estoque</a></li>\n';
menu += '<li class="'+ p7 +'"><a href="relatorios.html"><svg class="glyph stroked line-graph"><use xlink:href="#stroked-line-graph"></use></svg> Relatórios</a></li>\n';

menu += '<li class="'+ p8 +'">\n';
menu += '  <a href="#">\n';
menu += '    <span data-toggle="collapse" href="#sub-item-usuarios"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Usuários\n';
menu += '  </a>\n';
menu += '  <ul class="children collapse" id="sub-item-usuarios">\n';
menu += '    <li>\n';
menu += '      <a class="" href="usuarios_novo.html">\n';
menu += '        <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Usuários\n';
menu += '      </a>\n';
menu += '    </li>\n';
menu += '    <li>\n';
menu += '      <a class="" href="usuarios_regras.html">\n';
menu += '        <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Regras\n';
menu += '      </a>\n';
menu += '    </li>\n';
menu += '  </ul>\n';
menu += '</li>\n';


document.write(menu);
