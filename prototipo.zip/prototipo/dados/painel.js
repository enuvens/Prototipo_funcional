document.getElementById('label_01_n').innerHTML = "120";
document.getElementById('label_02_n').innerHTML = "24";
document.getElementById('label_03_n').innerHTML = "52";
document.getElementById('label_04_n').innerHTML = "25";
document.getElementById('label_01_t').innerHTML = "Vendas";
document.getElementById('label_02_t').innerHTML = "Em Produção";
document.getElementById('label_03_t').innerHTML = "Baixo Estoque";
document.getElementById('label_04_t').innerHTML = "Em falta";
