Prototipo funcional 
